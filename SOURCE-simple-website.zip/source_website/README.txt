SOURCE WEBSITE — QUICK START

1. Open index.html in a browser to preview the website.
2. Replace these placeholders in index.html:
   - YOUR-EMAIL@example.com
   - 07XXX XXXXXX
3. The enquiry form currently opens the visitor's email app. For a proper online form, connect it to a free service such as Formspree or Tally.
4. Upload both index.html and source-logo.jpeg to your website host.
5. Free or low-cost hosting options include GitHub Pages, Netlify and Cloudflare Pages. A custom .co.uk domain normally has a small yearly fee.

Note: The page currently uses one external Unsplash property image. Replace that image with one you own before launch if preferred.
